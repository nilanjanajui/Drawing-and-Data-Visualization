x <- 1L # integer
y <- 2  # numeric

# convert from integer to numeric:
a <- as.numeric(x)

# convert from numeric to integer:
b <- as.integer(y)

# print values of x and y
print(x)
print(y)

# print the class name of a and b
print(class(a))
print(class(b))

